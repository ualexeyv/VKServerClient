//
//  PhotoCollectionViewCell.swift
//  VKClientServer
//
//  Created by пользовтель on 15.07.2021.
//

import UIKit

class PhotoCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var photoImage: UIImageView!
    
}
