//
//  ViewController.swift
//  VKClientServer
//
//  Created by пользовтель on 06.07.2021.
//

import UIKit
import WebKit

class ViewController: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }


}

